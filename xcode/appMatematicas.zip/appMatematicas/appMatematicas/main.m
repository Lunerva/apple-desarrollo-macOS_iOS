//
//  main.m
//  appMatematicas
//
//  Created by Luis Barranco on 12/09/24.
//

#import <Foundation/Foundation.h>
#import "Matematicas.h"

int main() {
    Matematicas *mat = [[Matematicas alloc]init];

    NSNumber *a = [NSNumber numberWithFloat:10.5];
    NSNumber *b = [NSNumber numberWithFloat:10.0];
   
    NSNumber *result = [mat multiplyA:a withB:b];
    NSString *resultString = [result stringValue];
    NSLog(@"The product is %@",resultString);

   
    return 0;
}

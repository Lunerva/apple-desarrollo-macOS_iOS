//
//  AppDelegate.h
//  appCocoa1
//
//  Created by Luis Barranco on 13/09/24.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end


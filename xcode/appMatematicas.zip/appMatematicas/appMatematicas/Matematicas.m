//
//  Matematicas.m
//  appMatematicas
//
//  Created by Luis Barranco on 12/09/24.
//

#import "Matematicas.h"
@implementation Matematicas

-(NSNumber *)multiplyA:(NSNumber *)a withB:(NSNumber *)b {
   float number1 = [a floatValue];
   float number2 = [b floatValue];
   float product = number1 * number2;
   NSNumber *result = [NSNumber numberWithFloat:product];
   return result;
}

-(NSNumber *)factorialIterativo:(NSNumber *)a {
    NSInteger aux = 1;
    for(int i=1;i<=[a integerValue];i++){
        aux*=i;
    }
    return [NSNumber numberWithInteger:aux];
}

-(NSNumber *)factorialRecursivo:(NSNumber *)a{
    int cont = [a integerValue];
    if((cont == 0)||(cont == 1)){
        return [NSNumber numberWithInteger:1];
    }else{
        NSNumber *ant=[self factorialRecursivo:[NSNumber numberWithInteger:cont - 1]];
        return [NSNumber numberWithInteger:cont * [ant integerValue]];
    }
}

-(NSNumber *)sinAngular:(NSNumber *)a{
    CGFloat rad = [a doubleValue] * (M_PI)/180;
    CGFloat res = sinf(rad);
    return [NSNumber numberWithFloat:res];
}

-(int)factorial:(int)n{
    int f=1;
    if(n == 0 || n == 1){
        return f;
    }
    for(int i=1;i<=n;i++){
        
    }
    return 0;
}


@end

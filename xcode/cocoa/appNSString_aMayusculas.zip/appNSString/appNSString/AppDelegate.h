//
//  AppDelegate.h
//  appNSString
//
//  Created by Luis Barranco on 18/09/24.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

